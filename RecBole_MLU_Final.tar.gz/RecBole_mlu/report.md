# Cambricon PyTorch Model Migration Report
## Cambricon PyTorch Changes
| No. |  File  |  Description  |
| 1 | recbole/config/configurator.py:485 | add "import torch_mlu" |
| 2 | recbole/config/configurator.py:492 | change "if len(gpu_id) == 0 or not torch.cuda.is_available()" to "if len(gpu_id) == 0 or not torch.mlu.is_available() " |
| 3 | recbole/config/configurator.py:493 | change "else torch.device("cuda")" to "else torch.device("mlu") " |
| 4 | recbole/config/configurator.py:498 | change "backend="nccl"," to "backend="cncl", " |
| 5 | recbole/config/configurator.py:508 | change ""cuda", self.final_config_dict["local_rank"]" to ""mlu", self.final_config_dict["local_rank"] " |
| 6 | recbole/config/configurator.py:511 | change "torch.cuda.set_device(self.final_config_dict["local_rank"])" to "torch.mlu.set_device(self.final_config_dict["local_rank"]) " |
| 7 | recbole/data/interaction.py:17 | add "import torch_mlu" |
| 8 | recbole/data/transform.py:9 | add "import torch_mlu" |
| 9 | recbole/data/dataloader/abstract_dataloader.py:19 | add "import torch_mlu" |
| 10 | recbole/data/dataloader/general_dataloader.py:16 | add "import torch_mlu" |
| 11 | recbole/data/dataloader/user_dataloader.py:14 | add "import torch_mlu" |
| 12 | recbole/data/dataset/customized_dataset.py:20 | add "import torch_mlu" |
| 13 | recbole/data/dataset/dataset.py:24 | add "import torch_mlu" |
| 14 | recbole/data/dataset/kg_dataset.py:20 | add "import torch_mlu" |
| 15 | recbole/data/dataset/sequential_dataset.py:16 | add "import torch_mlu" |
| 16 | recbole/evaluator/base_metric.py:15 | add "import torch_mlu" |
| 17 | recbole/evaluator/collector.py:16 | add "import torch_mlu" |
| 18 | recbole/evaluator/utils.py:19 | add "import torch_mlu" |
| 19 | recbole/model/abstract_recommender.py:18 | add "import torch_mlu" |
| 20 | recbole/model/layers.py:22 | add "import torch_mlu" |
| 21 | recbole/model/loss.py:17 | add "import torch_mlu" |
| 22 | recbole/model/context_aware_recommender/afm.py:15 | add "import torch_mlu" |
| 23 | recbole/model/context_aware_recommender/autoint.py:15 | add "import torch_mlu" |
| 24 | recbole/model/context_aware_recommender/dcn.py:21 | add "import torch_mlu" |
| 25 | recbole/model/context_aware_recommender/dcnv2.py:18 | add "import torch_mlu" |
| 26 | recbole/model/context_aware_recommender/dssm.py:14 | add "import torch_mlu" |
| 27 | recbole/model/context_aware_recommender/eulernet.py:18 | add "import torch_mlu" |
| 28 | recbole/model/context_aware_recommender/ffm.py:23 | add "import torch_mlu" |
| 29 | recbole/model/context_aware_recommender/ffm.py:261 | change "token_ffm_input (torch.cuda.FloatTensor): [batch_size, num_token_features] or None" to "token_ffm_input (torch.mlu.FloatTensor): [batch_size, num_token_features] or None " |
| 30 | recbole/model/context_aware_recommender/ffm.py:263 | change "float_ffm_input (torch.cuda.FloatTensor): [batch_size, num_float_features] or None" to "float_ffm_input (torch.mlu.FloatTensor): [batch_size, num_float_features] or None " |
| 31 | recbole/model/context_aware_recommender/ffm.py:268 | change "torch.cuda.FloatTensor: The results of all features' field-aware interactions." to "torch.mlu.FloatTensor: The results of all features' field-aware interactions. " |
| 32 | recbole/model/context_aware_recommender/fignn.py:19 | add "import torch_mlu" |
| 33 | recbole/model/context_aware_recommender/fwfm.py:15 | add "import torch_mlu" |
| 34 | recbole/model/context_aware_recommender/fwfm.py:104 | change "infeature (torch.cuda.FloatTensor): [batch_size, field_size, embed_dim]" to "infeature (torch.mlu.FloatTensor): [batch_size, field_size, embed_dim] " |
| 35 | recbole/model/context_aware_recommender/fwfm.py:107 | change "torch.cuda.FloatTensor: [batch_size, 1]" to "torch.mlu.FloatTensor: [batch_size, 1] " |
| 36 | recbole/model/context_aware_recommender/kd_dagfm.py:16 | add "import torch_mlu" |
| 37 | recbole/model/context_aware_recommender/kd_dagfm.py:119 | change "if torch.cuda.is_available():" to "if torch.mlu.is_available(): " |
| 38 | recbole/model/context_aware_recommender/kd_dagfm.py:120 | change "self.device = torch.device("cuda")" to "self.device = torch.device("mlu") " |
| 39 | recbole/model/context_aware_recommender/kd_dagfm.py:252 | change "if torch.cuda.is_available():" to "if torch.mlu.is_available(): " |
| 40 | recbole/model/context_aware_recommender/kd_dagfm.py:253 | change "self.device = torch.device("cuda")" to "self.device = torch.device("mlu") " |
| 41 | recbole/model/context_aware_recommender/pnn.py:19 | add "import torch_mlu" |
| 42 | recbole/model/context_aware_recommender/xdeepfm.py:23 | add "import torch_mlu" |
| 43 | recbole/model/general_recommender/admmslim.py:15 | add "import torch_mlu" |
| 44 | recbole/model/general_recommender/asymknn.py:3 | add "import torch_mlu" |
| 45 | recbole/model/general_recommender/bpr.py:18 | add "import torch_mlu" |
| 46 | recbole/model/general_recommender/cdae.py:16 | add "import torch_mlu" |
| 47 | recbole/model/general_recommender/convncf.py:16 | add "import torch_mlu" |
| 48 | recbole/model/general_recommender/dgcf.py:24 | add "import torch_mlu" |
| 49 | recbole/model/general_recommender/dgcf.py:141 | change "A_values (torch.cuda.FloatTensor): (num_edge, n_factors)" to "A_values (torch.mlu.FloatTensor): (num_edge, n_factors) " |
| 50 | recbole/model/general_recommender/dgcf.py:147 | change "torch.cuda.FloatTensor: Sparse tensor of the normalized interaction matrix. shape: (num_edge, n_factors)" to "torch.mlu.FloatTensor: Sparse tensor of the normalized interaction matrix. shape: (num_edge, n_factors) " |
| 51 | recbole/model/general_recommender/dgcf.py:302 | change "cor_u_embeddings (torch.cuda.FloatTensor): (cor_batch_size, n_factors)" to "cor_u_embeddings (torch.mlu.FloatTensor): (cor_batch_size, n_factors) " |
| 52 | recbole/model/general_recommender/dgcf.py:303 | change "cor_i_embeddings (torch.cuda.FloatTensor): (cor_batch_size, n_factors)" to "cor_i_embeddings (torch.mlu.FloatTensor): (cor_batch_size, n_factors) " |
| 53 | recbole/model/general_recommender/diffrec.py:20 | add "import torch_mlu" |
| 54 | recbole/model/general_recommender/dmf.py:19 | add "import torch_mlu" |
| 55 | recbole/model/general_recommender/ease.py:8 | add "import torch_mlu" |
| 56 | recbole/model/general_recommender/enmf.py:16 | add "import torch_mlu" |
| 57 | recbole/model/general_recommender/fism.py:16 | add "import torch_mlu" |
| 58 | recbole/model/general_recommender/gcmc.py:26 | add "import torch_mlu" |
| 59 | recbole/model/general_recommender/itemknn.py:16 | add "import torch_mlu" |
| 60 | recbole/model/general_recommender/ldiffrec.py:18 | add "import torch_mlu" |
| 61 | recbole/model/general_recommender/lightgcn.py:24 | add "import torch_mlu" |
| 62 | recbole/model/general_recommender/line.py:19 | add "import torch_mlu" |
| 63 | recbole/model/general_recommender/macridvae.py:21 | add "import torch_mlu" |
| 64 | recbole/model/general_recommender/multidae.py:14 | add "import torch_mlu" |
| 65 | recbole/model/general_recommender/multivae.py:14 | add "import torch_mlu" |
| 66 | recbole/model/general_recommender/nais.py:21 | add "import torch_mlu" |
| 67 | recbole/model/general_recommender/nceplrec.py:16 | add "import torch_mlu" |
| 68 | recbole/model/general_recommender/ncl.py:13 | add "import torch_mlu" |
| 69 | recbole/model/general_recommender/ncl.py:95 | change "# convert to cuda Tensors for broadcast" to "# convert to mlu Tensors for broadcast " |
| 70 | recbole/model/general_recommender/neumf.py:18 | add "import torch_mlu" |
| 71 | recbole/model/general_recommender/ngcf.py:24 | add "import torch_mlu" |
| 72 | recbole/model/general_recommender/nncf.py:17 | add "import torch_mlu" |
| 73 | recbole/model/general_recommender/pop.py:20 | add "import torch_mlu" |
| 74 | recbole/model/general_recommender/ract.py:14 | add "import torch_mlu" |
| 75 | recbole/model/general_recommender/random.py:13 | add "import torch_mlu" |
| 76 | recbole/model/general_recommender/recvae.py:19 | add "import torch_mlu" |
| 77 | recbole/model/general_recommender/sgl.py:18 | add "import torch_mlu" |
| 78 | recbole/model/general_recommender/simplex.py:16 | add "import torch_mlu" |
| 79 | recbole/model/general_recommender/slimelastic.py:11 | add "import torch_mlu" |
| 80 | recbole/model/general_recommender/spectralcf.py:19 | add "import torch_mlu" |
| 81 | recbole/model/knowledge_aware_recommender/cfkg.py:13 | add "import torch_mlu" |
| 82 | recbole/model/knowledge_aware_recommender/cke.py:13 | add "import torch_mlu" |
| 83 | recbole/model/knowledge_aware_recommender/kgat.py:18 | add "import torch_mlu" |
| 84 | recbole/model/knowledge_aware_recommender/kgcn.py:18 | add "import torch_mlu" |
| 85 | recbole/model/knowledge_aware_recommender/kgin.py:21 | add "import torch_mlu" |
| 86 | recbole/model/knowledge_aware_recommender/kgnnls.py:21 | add "import torch_mlu" |
| 87 | recbole/model/knowledge_aware_recommender/ktup.py:16 | add "import torch_mlu" |
| 88 | recbole/model/knowledge_aware_recommender/mcclk.py:18 | add "import torch_mlu" |
| 89 | recbole/model/knowledge_aware_recommender/mkr.py:16 | add "import torch_mlu" |
| 90 | recbole/model/knowledge_aware_recommender/ripplenet.py:17 | add "import torch_mlu" |
| 91 | recbole/model/knowledge_aware_recommender/ripplenet.py:196 | change "o_list (dict -> torch.cuda.FloatTensor): list of torch.cuda.FloatTensor n_hop * [batch_size, embedding_size]" to "o_list (dict -> torch.mlu.FloatTensor): list of torch.mlu.FloatTensor n_hop * [batch_size, embedding_size] " |
| 92 | recbole/model/knowledge_aware_recommender/ripplenet.py:278 | change "o_list (dict -> torch.cuda.FloatTensor): list of torch.cuda.FloatTensor" to "o_list (dict -> torch.mlu.FloatTensor): list of torch.mlu.FloatTensor " |
| 93 | recbole/model/sequential_recommender/bert4rec.py:26 | add "import torch_mlu" |
| 94 | recbole/model/sequential_recommender/caser.py:23 | add "import torch_mlu" |
| 95 | recbole/model/sequential_recommender/core.py:13 | add "import torch_mlu" |
| 96 | recbole/model/sequential_recommender/dien.py:23 | add "import torch_mlu" |
| 97 | recbole/model/sequential_recommender/din.py:23 | add "import torch_mlu" |
| 98 | recbole/model/sequential_recommender/fdsa.py:16 | add "import torch_mlu" |
| 99 | recbole/model/sequential_recommender/fearec.py:23 | add "import torch_mlu" |
| 100 | recbole/model/sequential_recommender/fossil.py:17 | add "import torch_mlu" |
| 101 | recbole/model/sequential_recommender/fpmc.py:19 | add "import torch_mlu" |
| 102 | recbole/model/sequential_recommender/gcsan.py:18 | add "import torch_mlu" |
| 103 | recbole/model/sequential_recommender/gru4rec.py:20 | add "import torch_mlu" |
| 104 | recbole/model/sequential_recommender/gru4reccpr.py:27 | add "import torch_mlu" |
| 105 | recbole/model/sequential_recommender/gru4recf.py:16 | add "import torch_mlu" |
| 106 | recbole/model/sequential_recommender/gru4reckg.py:15 | add "import torch_mlu" |
| 107 | recbole/model/sequential_recommender/hgn.py:17 | add "import torch_mlu" |
| 108 | recbole/model/sequential_recommender/hrm.py:19 | add "import torch_mlu" |
| 109 | recbole/model/sequential_recommender/ksr.py:16 | add "import torch_mlu" |
| 110 | recbole/model/sequential_recommender/lightsans.py:15 | add "import torch_mlu" |
| 111 | recbole/model/sequential_recommender/narm.py:23 | add "import torch_mlu" |
| 112 | recbole/model/sequential_recommender/nextitnet.py:19 | add "import torch_mlu" |
| 113 | recbole/model/sequential_recommender/npe.py:19 | add "import torch_mlu" |
| 114 | recbole/model/sequential_recommender/repeatnet.py:20 | add "import torch_mlu" |
| 115 | recbole/model/sequential_recommender/s3rec.py:22 | add "import torch_mlu" |
| 116 | recbole/model/sequential_recommender/sasrec.py:18 | add "import torch_mlu" |
| 117 | recbole/model/sequential_recommender/sasreccpr.py:26 | add "import torch_mlu" |
| 118 | recbole/model/sequential_recommender/sasrecf.py:11 | add "import torch_mlu" |
| 119 | recbole/model/sequential_recommender/shan.py:17 | add "import torch_mlu" |
| 120 | recbole/model/sequential_recommender/sine.py:16 | add "import torch_mlu" |
| 121 | recbole/model/sequential_recommender/srgnn.py:20 | add "import torch_mlu" |
| 122 | recbole/model/sequential_recommender/stamp.py:20 | add "import torch_mlu" |
| 123 | recbole/model/sequential_recommender/transrec.py:15 | add "import torch_mlu" |
| 124 | recbole/quick_start/quick_start.py:248 | add "import torch_mlu" |
| 125 | recbole/sampler/sampler.py:20 | add "import torch_mlu" |
| 126 | recbole/trainer/trainer.py:26 | add "import torch_mlu" |
| 127 | recbole/trainer/trainer.py:30 | change "import torch.cuda.amp as amp" to "import torch.mlu.amp as amp " |
| 128 | recbole/trainer/trainer.py:126 | change "self.gpu_available = torch.cuda.is_available() and config["use_gpu"]" to "self.gpu_available = torch.mlu.is_available() and config["use_gpu"] " |
| 129 | recbole/trainer/trainer.py:130 | change "self.enable_scaler = torch.cuda.is_available() and config["enable_scaler"]" to "self.enable_scaler = torch.mlu.is_available() and config["enable_scaler"] " |
| 130 | recbole/utils/case_study.py:16 | add "import torch_mlu" |
| 131 | recbole/utils/utils.py:23 | add "import torch_mlu" |
| 132 | recbole/utils/utils.py:189 | change "r"""init random seed for random functions in numpy, torch, cuda and cudnn" to "r"""init random seed for random functions in numpy, torch, mlu and cudnn " |
| 133 | recbole/utils/utils.py:198 | change "torch.cuda.manual_seed(seed)" to "torch.mlu.manual_seed(seed) " |
| 134 | recbole/utils/utils.py:199 | change "torch.cuda.manual_seed_all(seed)" to "torch.mlu.manual_seed_all(seed) " |
| 135 | recbole/utils/utils.py:238 | change "device: cuda.device. It is the device that the model run on." to "device: mlu.device. It is the device that the model run on. " |
| 136 | recbole/utils/utils.py:244 | change "reserved = torch.cuda.max_memory_reserved(device) / 1024**3" to "reserved = torch.mlu.max_memory_reserved(device) / 1024**3 " |
| 137 | recbole/utils/utils.py:245 | change "total = torch.cuda.get_device_properties(device).total_memory / 1024**3" to "total = torch.mlu.get_device_properties(device).total_memory / 1024**3 " |
| 138 | recbole/utils/utils.py:256 | change "device: cuda.device. It is the device that the model run on." to "device: mlu.device. It is the device that the model run on. " |
| 139 | recbole/utils/utils.py:421 | change "if torch.cuda.is_available() and config["use_gpu"]" to "if torch.mlu.is_available() and config["use_gpu"] " |
| 140 | run_example/case_study_example.py:13 | add "import torch_mlu" |
